<template>
  <div class="footer">

  </div>
</template>
<script>
export default {
  name: 'footer'
}
</script>
<style lang="scss" scoped>
</style>