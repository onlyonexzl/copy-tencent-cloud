import article from '@/request/api/article'

// 导出接口
export default {
  article
}
