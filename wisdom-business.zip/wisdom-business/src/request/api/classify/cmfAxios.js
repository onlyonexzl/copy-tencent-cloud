let funJson = {
  axios (parment) {
    return 1
  }
}

export default funJson
